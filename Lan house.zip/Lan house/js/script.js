function calcular(){
    let valor = Math.ceil(parseFloat(document.getElementById('valor').value)) * Math.ceil(parseFloat(document.getElementById('tempo').value / 15));
    console.log(valor);
    document.getElementById('resultado').textContent = "Valor a pagar R$: " + valor + ".00";
}