function promocao(){
    let promocao = Math.floor(parseFloat(document.getElementById('preco').value) * 2);
    let medicamento = document.getElementById('medica').value;
    document.getElementById('promo').textContent = 'Promoção de ' + medicamento + ".\nLeve 2 por apenas R$: " + promocao + ".00";
}