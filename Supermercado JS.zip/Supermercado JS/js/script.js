function calcular(){
    var promo = parseFloat(document.getElementById('preco').value) / 2;
    var resul = (parseFloat(document.getElementById('preco').value) * 3) - promo;
    document.getElementById('resultado').textContent = document.getElementById('produto').value + " - Promoção: Leve 3 por R$: " + resul;
    document.getElementById('promo').textContent = "O 3º produto custa apenas R$: " + promo;
}